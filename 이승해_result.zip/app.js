
var client = require('cheerio-httpcli');
let request = require('request');


const json = '{"portal":"네이버","title":"신의 탑"}' //입력데이터
const obj = JSON.parse(json); 

const express = require('express');
const bodyParser = require('body-parser');
const app = express();

//네이버웹툰 접속시
if(obj.portal.toUpperCase() == "NAVER" || obj.portal == "네이버"){   
    //웹툰 첫페이지 접속
    client.fetch("http://comic.naver.com/webtoon/weekday.nhn", {}, function (err, $, res, body) {
        var list = $(".list_area .col li");
        var checkNum = 0; //몇번쨰 웹툰인지 체크하기위한 변수
        var atag = "test"; //다음페이지 접속주소
    
        list.each(function(){
        
            if(obj.title == $(this).find(".title").text()){
            
    		    atag = $('.thumb a')[checkNum];
            
    	    };
    	    checkNum++;
        });

    	//검색된 해당웹툰 페이지 접속
    	client.fetch("http://comic.naver.com" + atag.attribs.href,{}, function (err, $, res, body) {
    
    
    		list = $(".viewList .title a");
    
    
    		for(var i=0; i<5;i++){

    			//최근 5개화 정보추출	
				try{
				var nanana = client.fetchSync("http://comic.naver.com" + list[i].children[0].parent.attribs.href);
				}catch(e){
					break;
				}
				if(nanana){
					
					
					
				};
				var data={
    				    title:nanana.$(".view h3").text(),
    				    day:nanana.$(".date").text(),
    				    grade:nanana.$(".total #topPointTotalNumber").text(),
    				    people:nanana.$(".total #topTotalStarPoint .pointTotalPerson em").text()
    				};
					
    			console.log(data);
					
    			
            
    		};
        
    	});
    
    });
//다음웹툰 접속시
}else if(obj.portal.toUpperCase() == "DAUM" || obj.portal == "다음"){
	//웹툰 검색
	client.fetch("http://webtoon.daum.net/data/pc/search?q="+encodeURIComponent(obj.title)+"&page_no=1",{}, function (err, $, res, body) {
		
		body = JSON.parse(body);
		var nextPage = body.data.webtoon[0].nickname;

		client.fetch("http://webtoon.daum.net/data/pc/webtoon/view/"+encodeURIComponent(nextPage),{}, function (err, $, res, body) {
		
		    var freeCheckNum = 0;
		    body = JSON.parse(body);
    
		    for(let i = 0; i<body.data.webtoon.webtoonEpisodes.length; i++){
		    	if(body.data.webtoon.webtoonEpisodes[i].serviceType=="free"){
                
		    		var UploadDay = body.data.webtoon.webtoonEpisodes[i].dateCreated.substr(0,8);
		    		var WebId = body.data.webtoon.webtoonEpisodes[i].id;
		    		var avr = Math.floor(body.data.webtoon.averageScore*100)/100;
		    		var title = body.data.webtoon.webtoonEpisodes[i].title;
                
		    		var data={
		    			title:title,
		    			day:UploadDay,
		    			grade:avr,
		    			people:0
					};
					
					var nanana = client.fetchSync("http://webtoon.daum.net/data/pc/webtoon/viewer/"+encodeURIComponent(WebId));
					var bodyData = JSON.parse(nanana.body);
		    		var people = bodyData.data.webtoonEpisode.voteTarget.voteCount;
		    		data.people = people;
		    		console.log(data);


		    		
                
		    		freeCheckNum++;
		    		if(freeCheckNum>4)break;
                
		    	};
            
		    };
		
		
		});
		
	});
	
	
	
}else{
	console.log("페이지입력이 잘못되었습니다.");
}
